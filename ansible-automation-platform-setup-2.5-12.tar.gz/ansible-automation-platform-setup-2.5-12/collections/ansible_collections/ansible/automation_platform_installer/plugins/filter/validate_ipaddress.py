# Copyright: (c) 2025, Ansible Automation Platform
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import absolute_import, division, print_function

__metaclass__ = type

from ipaddress import ip_address


class FilterModule(object):
    '''Checks the syntax of IP address values'''

    def validate_ipaddress(self, val):
        try:
            ip_address(val)
        except ValueError:
            return False
        return True

    def filters(self):
        return {'validate_ipaddress': self.validate_ipaddress}
